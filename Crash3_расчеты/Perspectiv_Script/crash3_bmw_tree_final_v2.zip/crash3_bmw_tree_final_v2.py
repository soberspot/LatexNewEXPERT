#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
crash3_bmw_tree_full_viz.py

Полная реконструкция: BMW X6 (2018) vs Дерево.
Включает:
- Матричный расчет энергии (Grid Method).
- Расчет EES (Energy Equivalent Speed).
- 2D и 3D визуализацию.
"""

from __future__ import annotations

import math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

# ==============================================================================
# 1. ПАРАМЕТРЫ СЦЕНАРИЯ
# ==============================================================================

# --- НАСТРОЙКИ УДАРА (МОЖНО МЕНЯТЬ ЗДЕСЬ) ---
MAX_DEPTH_IMPACT = 0.30      # м (Глубина вдавливания: 40 см)
OFFSET_FROM_CENTER = 0.20    # м (Смещение влево от центра авто)
TREE_DIAMETER = 0.82         # м

# --- ПАРАМЕТРЫ АВТОМОБИЛЯ (BMW X6 Unibody) ---
A_BMW = 1e6 #  3.20e5       # Н/м (Жесткость бампера/панелей)
B_BMW = 1e6 # 4.10e6       # Н/м^2 (Жесткость лонжеронов/мотора)
C0_BMW = 0.05        # м (Толщина декоративного пластика)
CELL_W = 0.125       # м (Размер ячейки сетки)

M_BMW = 2350.0       # кг (Масса)

ROWS = 11  # Высота
COLS = 16  # Ширина

# ==============================================================================
# 2. ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ (РАСЧЕТ)
# ==============================================================================

def generate_tree_damage_profile():
    """Генерация матрицы деформации (C) от цилиндрического дерева."""
    c_mat = np.zeros((ROWS, COLS), dtype=float)

    # Геометрия: Центр авто = 1.0м. Смещение влево 0.2м -> Центр удара 0.8м
    car_width = COLS * CELL_W
    impact_center_x = (car_width / 2.0) - OFFSET_FROM_CENTER

    tree_radius = TREE_DIAMETER / 2.0

    for col in range(COLS):
        # Координата центра столбца
        cx = col * CELL_W + (CELL_W / 2)
        dist = abs(cx - impact_center_x)

        if dist < tree_radius:
            # Геометрия круга: y = sqrt(R^2 - x^2)
            circle_y = math.sqrt(tree_radius**2 - dist**2)

            # Профиль глубины
            depth = MAX_DEPTH_IMPACT - (tree_radius - circle_y)

            # Если depth < 0 (края), обнуляем
            if depth < 0: depth = 0

            for row in range(ROWS):
                # Смягчаем края сверху/снизу (капот/юбка)
                factor = 1.0
                if row == 0 or row == ROWS-1: factor = 0.8

                c_mat[row, col] = depth * factor
    return c_mat

def get_stiffness_matrix():
    """Карта жесткости (K_rel) для BMW X6."""
    k_rel = np.full((ROWS, COLS), 0.3, dtype=float) # База

    # Лонжероны
    k_rel[4:9, 4:6] = 1.5 
    k_rel[4:9, 10:12] = 1.5

    # Усилитель бампера
    k_rel[6:8, :] += 0.5

    # ДВИГАТЕЛЬ (Блок) - Самая жесткая зона
    # Если удар глубокий, жесткость работает. Если поверхностный - нет.
    # Мы задаем карту "потенциальной" жесткости.
    k_rel[3:9, 6:10] = 5.0

    # Чашки подвески
    k_rel[2:5, 3:5] = 2.5
    k_rel[2:5, 11:13] = 2.5

    return k_rel

def calculate_energy(c_mat, k_rel):
    """Grid Method интеграл."""
    # Нормировка K
    mask = k_rel > 0
    k_mean = k_rel[mask].mean() if np.any(mask) else 1.0
    k_norm = k_rel / k_mean

    # Локальные A, B
    A_ij = A_BMW * k_norm
    B_ij = B_BMW * k_norm

    # Эффективная глубина (минус пластик)
    c_eff = np.maximum(0.0, c_mat - C0_BMW)

    # Энергия ячейки
    E_grid = CELL_W * (0.5 * A_ij * c_eff**2 + (1.0/3.0) * B_ij * c_eff**3)
    return E_grid

def analyze_srs(ees_kmh):
    """Анализ подушек по EES."""
    if ees_kmh < 15: return "NO FIRE (Только ремни)"
    if 15 <= ees_kmh < 25: return "GREY ZONE / STAGE 1 (Водитель + преднатяжители)"
    if ees_kmh >= 25: return "MUST FIRE (Все подушки + размыкание АКБ)"

# ==============================================================================
# 3. ФУНКЦИИ ВИЗУАЛИЗАЦИИ (3D RESTORED)
# ==============================================================================

def plot_3d_damage(c_mat, out_dir):
    """Строит красивую 3D поверхность повреждений."""
    x = np.linspace(0, COLS * CELL_W, COLS)
    y = np.linspace(ROWS * CELL_W, 0, ROWS) # 0 вверху (по индексу), но на графике Y
    X, Y = np.meshgrid(x, y)

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    # Рисуем поверхность
    surf = ax.plot_surface(X, Y, c_mat, cmap='viridis', edgecolor='none', alpha=0.9)

    ax.set_title(f'3D Профиль деформации (Глубина {MAX_DEPTH_IMPACT*100:.0f} см)', fontsize=14)
    ax.set_xlabel('Ширина (м)')
    ax.set_ylabel('Высота от земли (м)')
    ax.set_zlabel('Глубина вдавливания (м)')

    # Настройка вида
    ax.view_init(elev=35, azim=-110)
    ax.set_zlim(0, 0.8) # Фиксируем масштаб Z для наглядности сравнения

    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=10, label='Метры')

    save_path = out_dir / "3d_damage_bmw.png"
    plt.savefig(save_path, dpi=300)
    print(f"[OK] 3D график повреждений сохранен: {save_path}")

def plot_3d_energy(e_mat, out_dir):
    """Строит 3D поверхность поглощенной ЭНЕРГИИ."""
    x = np.linspace(0, COLS * CELL_W, COLS)
    y = np.linspace(ROWS * CELL_W, 0, ROWS)
    X, Y = np.meshgrid(x, y)

    # Перевод в кДж
    Z = e_mat / 1000.0

    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    # Используем 'magma' или 'inferno' для отображения "жара" энергии
    surf = ax.plot_surface(X, Y, Z, cmap='magma', edgecolor='none', alpha=0.95)

    ax.set_title('3D Распределение Энергии Деформации (кДж)', fontsize=14)
    ax.set_xlabel('Ширина (м)')
    ax.set_ylabel('Высота от земли (м)')
    ax.set_zlabel('Энергия (кДж)')

    ax.view_init(elev=35, azim=-110)

    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=10, label='Энергия (кДж)')

    save_path = out_dir / "3d_energy_bmw.png"
    plt.savefig(save_path, dpi=300)
    print(f"[OK] 3D график энергии сохранен: {save_path}")

# ==============================================================================
# 4. MAIN
# ==============================================================================

def main():
    out_dir = Path(__file__).parent / "bmw_tree_output"
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f"=== РАСЧЕТ: BMW X6 (Глубина {MAX_DEPTH_IMPACT} м) ===")

    # 1. Генерация данных
    C_MAT = generate_tree_damage_profile()
    K_MAT = get_stiffness_matrix()

    # 2. Расчет энергии
    E_MAT = calculate_energy(C_MAT, K_MAT)
    E_total_joules = float(E_MAT.sum())

    # 3. Расчет скоростей
    # EES (Energy Equivalent Speed) - скорость, эквивалентная энергии деформации.
    # Для удара о неподвижное дерево (барьер) EES равна Скорости удара (V_impact).
    ees_ms = math.sqrt(2 * E_total_joules / M_BMW)
    ees_kmh = ees_ms * 3.6

    v_impact_kmh = ees_kmh  # При ударе о жесткое препятствие (дерево) вся скорость гасится в ноль

    # 4. Вердикт SRS
    srs_verdict = analyze_srs(ees_kmh)

    # 5. Печать отчета в консоль
    print(f"\nРЕЗУЛЬТАТЫ РАСЧЕТА:")
    print(f"--------------------------------------------------")
    print(f"1. ЭНЕРГИЯ ДЕФОРМАЦИИ:  {E_total_joules/1000.0:.2f} кДж")
    print(f"2. EES (Delta-V):       {ees_kmh:.2f} км/ч")
    print(f"3. СКОРОСТЬ УДАРА:      {v_impact_kmh:.2f} км/ч")
    print(f"4. СТАТУС SRS:          {srs_verdict}")
    print(f"--------------------------------------------------")

    # ==========================================================================
    # 5. ВИЗУАЛИЗАЦИЯ И СОХРАНЕНИЕ
    # ==========================================================================

    # --- 1. 2D ТЕПЛОВЫЕ КАРТЫ ---
    fig, axs = plt.subplots(1, 3, figsize=(18, 6))
    fig.suptitle(f"Анализ: BMW X6 (Глубина {MAX_DEPTH_IMPACT}м) | V = {v_impact_kmh:.1f} км/ч", fontsize=16)

    # Размеры для осей (0..Ширина, Высота..0)
    extent = [0, COLS * CELL_W, ROWS * CELL_W, 0]

    # График A: Глубина
    im1 = axs[0].imshow(C_MAT, cmap='Blues', extent=extent, vmin=0, vmax=MAX_DEPTH_IMPACT + 0.1)
    axs[0].set_title('Профиль деформации (м)')
    axs[0].set_xlabel('Ширина (м)')
    axs[0].set_ylabel('Высота (м)')
    fig.colorbar(im1, ax=axs[0], fraction=0.046, pad=0.04)

    # График B: Жесткость
    im2 = axs[1].imshow(K_MAT, cmap='Greys', extent=extent)
    axs[1].set_title('Карта жесткости (K_rel)')
    axs[1].set_xlabel('Ширина (м)')
    # Подсветим зону двигателя красным контуром (примерно)
    # rect = plt.Rectangle((0.8, 0.4), 0.5, 0.6, linewidth=1, edgecolor='r', facecolor='none')
    # axs[1].add_patch(rect)
    fig.colorbar(im2, ax=axs[1], fraction=0.046, pad=0.04)

    # График C: Энергия
    im3 = axs[2].imshow(E_MAT/1000.0, cmap='hot', extent=extent, interpolation='bicubic')
    axs[2].set_title('Плотность энергии (кДж)')
    axs[2].set_xlabel('Ширина (м)')
    fig.colorbar(im3, ax=axs[2], fraction=0.046, pad=0.04, label='кДж')

    plt.tight_layout()
    save_path_2d = out_dir / "2d_analysis_bmw.png"
    plt.savefig(save_path_2d, dpi=300)
    print(f"[OK] 2D графики сохранены: {save_path_2d}")

    # --- 2. 3D ВИЗУАЛИЗАЦИЯ (Вызов функций) ---
    plot_3d_damage(C_MAT, out_dir)
    plot_3d_energy(E_MAT, out_dir)

    # --- 3. ТЕКСТОВЫЙ ОТЧЕТ ---
    report_path = out_dir / "report_bmw_tree.txt"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"=== CRASH RECONSTRUCTION REPORT ===\n")
        f.write(f"Vehicle: BMW X6 (Unibody)\n")
        f.write(f"Object:  Tree (D={TREE_DIAMETER}m)\n\n")
        f.write(f"INPUTS:\n")
        f.write(f"Max Depth: {MAX_DEPTH_IMPACT} m\n")
        f.write(f"Offset:    {OFFSET_FROM_CENTER} m (Left)\n\n")
        f.write(f"RESULTS:\n")
        f.write(f"Energy:    {E_total_joules:.1f} J\n")
        f.write(f"EES:       {ees_kmh:.2f} km/h\n")
        f.write(f"Impact V:  {v_impact_kmh:.2f} km/h\n")
        f.write(f"SRS Check: {srs_verdict}\n")

    print(f"[OK] Отчет сохранен: {report_path}")

    # Показать окна
    plt.show()

if __name__ == "__main__":
    main()